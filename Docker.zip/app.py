from flask import Flask, render_template, request, jsonify
import pickle
import pandas as pd

app = Flask(__name__)

# Cargar el modelo y scaler
with open('mejor_modelo_xgb.pkl', 'rb') as modelo_file:
    modelo = pickle.load(modelo_file)

with open('scaler.pkl', 'rb') as scaler_file:
    scaler = pickle.load(scaler_file)

def predecir(diccionario):
    try:
        # Convertir el diccionario en un DataFrame
        df = pd.DataFrame([diccionario])

        # Escalar los datos
        df_scaled = scaler.transform(df)

        # Realizar la predicción
        prediccion = modelo.predict(df_scaled)
        probs = modelo.predict_proba(df_scaled)
        resultado = "Renunciará" if prediccion[0] == 1 else "No renunciará"
        probabilidad = f"(Probabilidad de Renuncia estimada = {probs[0][1].round(4)})"


        if prediccion[0] == 1:
            resultado = f'<span style="color: red;">{resultado}</span>'
        else:
            resultado = f'<span>{resultado}</span>'

        resultado = f"{resultado}<br>{probabilidad}"

        return resultado
    except Exception as e:
        return f'Error: {str(e)}'

# Ruta principal para el formulario
@app.route('/')
def home():
    return render_template('index.html')

# Ruta para procesar la predicción
@app.route('/predecir', methods=['POST'])
def predict():
    try:
        # Obtener los valores del formulario
        feature1 = float(request.form['feature1'])
        feature2 = float(request.form['feature2'])
        feature3 = float(request.form['feature3'])
        feature4 = float(request.form['feature4'])
        feature5 = float(request.form['feature5'])
        feature6 = float(request.form['feature6'])
        feature7 = float(request.form['feature7'])
        feature8 = float(request.form['feature8'])
        feature9 = float(request.form['feature9'])


        # Crear el diccionario con las características
        diccionario = {
            'Años de experiencia': feature1,
            'Tiempo de inactividad total': feature2,
            'Incidentes de peligro': feature3,
            'KM x Viaje': feature4,
            'Tiempo de inactividad x Viaje': feature5,
            'Score norm': feature6,
            'Finanzas': feature7,
            'Operaciones': feature8,
            'RH': feature9
        }
        # Hacer la predicción
        resultado = predecir(diccionario)

        return render_template('index.html', resultado=resultado)
    except Exception as e:
        return render_template('index.html', error=str(e))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
